#pragma once

#define HTTP_SERVER "194.180.158.163"
#define HTTP_PORT 80

#define TFTP_SERVER "194.180.158.163"
