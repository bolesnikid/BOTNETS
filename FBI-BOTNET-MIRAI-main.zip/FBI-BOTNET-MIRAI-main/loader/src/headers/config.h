#pragma once

#define HTTP_SERVER "84.201.154.133"
#define HTTP_PORT 80

#define TFTP_SERVER "84.201.154.133"
